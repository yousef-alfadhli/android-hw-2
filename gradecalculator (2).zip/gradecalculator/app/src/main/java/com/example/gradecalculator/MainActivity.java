package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editText1);
        final EditText y = findViewById(R.id.editText2);
        final EditText z = findViewById(R.id.editText3);
        final EditText a = findViewById(R.id.editText4);
        Button calculate = findViewById(R.id.button);
        final TextView C = findViewById(R.id.textView2);
        TextView V =findViewById(R.id.textView);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(x.getText().toString());
                int n2 = Integer.parseInt(y.getText().toString());
                int n3 = Integer.parseInt(z.getText().toString());
                int n4 = Integer.parseInt(a.getText().toString());
                int Sum = n1 + n2 + n3 + n4;
                C.setText(Sum);







            }
        });
    }


}